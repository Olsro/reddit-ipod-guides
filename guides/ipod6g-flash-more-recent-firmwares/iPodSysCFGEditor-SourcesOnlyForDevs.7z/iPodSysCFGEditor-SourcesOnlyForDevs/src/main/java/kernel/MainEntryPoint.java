package kernel;

public class MainEntryPoint {

    public static void main(String[] args) {
        Main.main(args);
    }
}
package kernel;

import java.io.IOException;

import controllers.MainController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static final String VERSION = "1.1";

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/main.fxml"));
        loader.setController(new MainController());
        Parent parent = loader.load();
        MainController controller = loader.getController();
        controller.setStageAndSetupListeners(stage);

        // Assign the loaded view to the stage and show it
        Scene scene = new Scene(parent);
        stage.setTitle("iPod SysCFG Editor v" + VERSION);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
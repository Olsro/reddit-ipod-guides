package controllers;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.util.*;
import java.util.function.UnaryOperator;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import kernel.Main;
import objects.SysCFG;
import objects.SysCFGEntryType;
import objects.iPodModelsBySNEnding;
import utils.StringUtils;

public class MainController {
    private Stage stage;
    private SysCFG loadedSysCFG;
    private SysCFG loadedSysCFGUntouched;
    private File loadedSysCFGFile;
    private boolean advancedEditMode;
    private Map<SysCFGEntryType, TextField> sysCfgEntryTypeToTf;
    @FXML private TextField tf0;
    @FXML private TextField tf1;
    @FXML private TextField tf2;
    @FXML private TextField tf3;
    @FXML private TextField tf4;
    @FXML private TextField tf5;
    @FXML private TextField tf6;
    @FXML private TextField tf7;
    @FXML private TextField tf8;
    @FXML private GridPane gridPane;
    @FXML private Label statusLabel;
    @FXML private Label syscfgPathLabel;
    @FXML private Label changesDetectedLabel;
    @FXML private Label snInterpretationLabel;

    @FXML private MenuButton applyEditPresetButton;
    @FXML private Button saveAsButton;
    @FXML private Button restoreValuesButton;

    @FXML private MenuItem restoreValuesMenuItem;
    @FXML private MenuItem saveMenuItem;
    @FXML private MenuItem closeMenuItem;
    @FXML private MenuItem saveAsMenuItem;
    @FXML private MenuItem enableAdvancedEditModeMenuItem;

    public MainController() {
    }

    public void setStageAndSetupListeners(Stage stage) {
        sysCfgEntryTypeToTf = new HashMap<>();
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_SRNM, tf0);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_FWID, tf1);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_HWID, tf2);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_HWVR, tf3);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_CODC, tf4);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_SWVR, tf5);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_MLBN, tf6);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_MODN, tf7);
        sysCfgEntryTypeToTf.put(SysCFGEntryType.SYSCFG_TAG_REGN, tf8);
        this.stage = stage;
        UnaryOperator<TextFormatter.Change> tFilter = change -> {
            if (!change.isContentChange()) {
                return change;
            }
            if (loadedSysCFG != null) {
                Control control = change.getControl();
                String text = change.getControlNewText().toUpperCase();
                String textWithoutSpaces = text.replace(" ", "");
                SysCFGEntryType sysCFGEntryType = null;
                for (Map.Entry<SysCFGEntryType, TextField> entry : sysCfgEntryTypeToTf.entrySet()) {
                    if (entry.getValue() == control) {
                        sysCFGEntryType = entry.getKey();
                        break;
                    }
                }
                int minLen = 1;
                int maxLen = SysCFG.SYSCFG_ENTRY_SIZE;

                if (sysCFGEntryType == SysCFGEntryType.SYSCFG_TAG_FWID) {
                    maxLen = 8;
                } else if (sysCFGEntryType == SysCFGEntryType.SYSCFG_TAG_HWID) {
                    maxLen = 8;
                } else if (sysCFGEntryType == SysCFGEntryType.SYSCFG_TAG_HWVR) {
                    maxLen = 6;
                } else if (sysCFGEntryType == SysCFGEntryType.SYSCFG_TAG_CODC) {
                    maxLen = 2;
                } else if (sysCFGEntryType == SysCFGEntryType.SYSCFG_TAG_REGN) {
                    minLen = maxLen;
                }
                if (sysCFGEntryType == null) {
                    return null;
                }
                if (textWithoutSpaces.length() > maxLen) {
                    return null;
                }
                if (textWithoutSpaces.length() < minLen) {
                    return null;
                }
                if (sysCFGEntryType.isStringFormatFunction()) {
                    if (!StringUtils.isValidInputString(textWithoutSpaces)) {
                        return null;
                    }
                } else {
                    if (!StringUtils.isUpperHexaString(textWithoutSpaces)) {
                        return null;
                    }
                }
                if (sysCFGEntryType.hasWriteFunction()) {
                    try {
                        byte[] pv = loadedSysCFG.entries().get(sysCFGEntryType);
                        loadedSysCFG.entries().put(sysCFGEntryType, sysCFGEntryType.getDataToWrite(textWithoutSpaces, pv));
                    } catch (Exception e) {
                        Alert alert = new Alert(Alert.AlertType.ERROR,
                                String.format("""
                            Error while writing '%s' into the field '%s' of SysCFG because: %s""", textWithoutSpaces, sysCFGEntryType, e.getMessage())
                                , ButtonType.OK);
                        alert.setTitle("Error");
                        alert.showAndWait();
                        e.printStackTrace();
                        return null;
                    }
                }
            }
            change.setText(change.getText().toUpperCase());
            refreshUI();
            return change;
        };
        this.tf0.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf1.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf2.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf3.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf4.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf5.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf6.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf7.setTextFormatter(new TextFormatter<>(tFilter));
        this.tf8.setTextFormatter(new TextFormatter<>(tFilter));
        Alert alert = new Alert(Alert.AlertType.WARNING,
                """
                The SysCFG is stored in the bootflash of your iPod and iTunes will NOT be able to restore it when it is corrupted.
                
                You need to use external tools to flash the SysCFG in the bootflash. Never shut down your iPod while it is flashing: plug your iPod to your charger to ensure it does not lose power during flashing.
                
                Make BACKUPS of your working stock SysCFG in multiple safe places !!!
                
                This program helps you to modify conveniently your SysCFG dumps and will reject automatically some blatant input errors by providing some validation and automation. Use this program with intelligence and enjoy it.
                
                The iPod SysCFG Editor is provided as-it-is under the MIT licence by hoping it will be useful to someone."""
                , ButtonType.OK);
        alert.setTitle("Welcome to the iPod SysCFG Editor");
        alert.showAndWait();
    }

    @FXML
    private void onOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Please select a valid syscfg file");
        File file = fileChooser.showOpenDialog(stage);
        if (file == null) {
            return;
        }
        loadSysCFGFile(file);
    }

    private void loadSysCFGFile(File file) {
        if (file == null) {
            return;
        }
        SysCFG sysCFG = null;
        try {
            byte[] data = Files.readAllBytes(file.toPath());
            ByteBuffer buffer = ByteBuffer.wrap(data);
            sysCFG = SysCFG.parse(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (sysCFG == null) {
            System.err.println("FATAL Error: Could not load SYSCFG");
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    String.format("""
                The file '%s' is not a valid SysCFG file !""", file.toPath())
                    , ButtonType.OK);
            alert.setTitle("Error");
            alert.showAndWait();
            return;
        }
        setLoadedSysCfg(sysCFG, file);
    }

    @FXML
    private void onCloseFile() {
        setLoadedSysCfg(null, null);
    }

    private void setLoadedSysCfg(SysCFG sysCFG, File sysCFGFile) {
        loadedSysCFG = sysCFG;
        loadedSysCFGFile = sysCFGFile;
        if (sysCFG != null) {
            statusLabel.setText("SysCFG file loaded !");
            loadedSysCFGUntouched = new SysCFG(sysCFG.header(), new EnumMap<>(sysCFG.entries()));
        } else {
            statusLabel.setText("SysCFG file not loaded !");
            loadedSysCFGUntouched = null;
        }
        if (sysCFG != null) {
            statusLabel.setTextFill(Paint.valueOf(Color.GREEN.toString()));
            syscfgPathLabel.setText(sysCFGFile.toPath().toString());
            tf0.setText(SysCFGEntryType.SYSCFG_TAG_SRNM.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_SRNM)));
            tf1.setText(SysCFGEntryType.SYSCFG_TAG_FWID.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_FWID)));
            tf2.setText(SysCFGEntryType.SYSCFG_TAG_HWID.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_HWID)));
            tf3.setText(SysCFGEntryType.SYSCFG_TAG_HWVR.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_HWVR)));
            tf4.setText(SysCFGEntryType.SYSCFG_TAG_CODC.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_CODC)));
            tf5.setText(SysCFGEntryType.SYSCFG_TAG_SWVR.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_SWVR)));
            tf6.setText(SysCFGEntryType.SYSCFG_TAG_MLBN.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_MLBN)));
            tf7.setText(SysCFGEntryType.SYSCFG_TAG_MODN.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_MODN)));
            tf8.setText(SysCFGEntryType.SYSCFG_TAG_REGN.getPrintableValue(sysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_REGN)));
        } else {
            statusLabel.setTextFill(Paint.valueOf(Color.RED.toString()));
            syscfgPathLabel.setText("");
            tf0.setText("");
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
            tf4.setText("");
            tf5.setText("");
            tf6.setText("");
            tf7.setText("");
            tf8.setText("");
        }
        gridPane.setDisable(sysCFG == null);
        tf0.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_SRNM.hasWriteFunction());
        tf1.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_FWID.hasWriteFunction());
        tf2.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_HWID.hasWriteFunction());
        tf3.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_HWVR.hasWriteFunction());
        tf4.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_CODC.hasWriteFunction());
        tf5.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_SWVR.hasWriteFunction());
        tf6.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_MLBN.hasWriteFunction());
        tf7.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_MODN.hasWriteFunction());
        tf8.setDisable(sysCFG == null || !SysCFGEntryType.SYSCFG_TAG_REGN.hasWriteFunction());
        closeMenuItem.setDisable(sysCFG == null);
        saveAsMenuItem.setDisable(sysCFG == null);
        enableAdvancedEditModeMenuItem.setDisable(sysCFG == null);
        refreshUI();
    }

    @FXML
    private void onEnableAdvancedEditMode() {
        if (advancedEditMode) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Advanced edit mode is already enabled until you quit the app."
                    , ButtonType.OK);
            alert.setTitle("Already enabled !");
            alert.showAndWait();
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                """
                This action will enable the "Advanced Edit Mode" until you quit this program.
                
                This powerful mode allows you to edit your SysCFG to your liking with a lot of freedom.
                
                With big power comes big responsibilities, so use this mode carefully.
                Be aware that modifying or flashing improperly the SysCFG will brick or semi-brick your iPod until you will flash a working backup.
                
                So... MAKE BACKUPS !!"""
                , ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Enable Advanced Edit Mode ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            advancedEditMode = true;
            refreshUI();
        }
    }

    private void refreshUI() {
        tf0.setEditable(advancedEditMode);
        tf1.setEditable(advancedEditMode);
        tf2.setEditable(advancedEditMode);
        tf3.setEditable(advancedEditMode);
        tf4.setEditable(advancedEditMode);
        tf5.setEditable(advancedEditMode);
        tf6.setEditable(advancedEditMode);
        tf7.setEditable(advancedEditMode);
        tf8.setEditable(advancedEditMode);
        if (loadedSysCFG == null) {
            snInterpretationLabel.setText("");
        } else {
            snInterpretationLabel.setText(objects.iPodModelsBySNEnding.getDescriptionBySNEnding(
                    SysCFGEntryType.SYSCFG_TAG_SRNM.getPrintableValue(loadedSysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_SRNM))));
        }
        boolean modified = false;
        if (loadedSysCFG != null && loadedSysCFGUntouched != null) {
            for (Map.Entry<SysCFGEntryType, byte[]> entry : loadedSysCFG.entries().entrySet()) {
                modified = !Arrays.equals(entry.getValue(), loadedSysCFGUntouched.entries().get(entry.getKey()));
                if (modified) {
                    break;
                }
            }
        }
        applyEditPresetButton.setDisable(loadedSysCFG == null);
        saveAsButton.setDisable(loadedSysCFG == null);
        saveMenuItem.setDisable(loadedSysCFG == null|| !modified);
        restoreValuesButton.setDisable(loadedSysCFG == null || !modified);
        restoreValuesMenuItem.setDisable(loadedSysCFG == null || !modified);
        changesDetectedLabel.setVisible(loadedSysCFG != null && modified);
    }

    @FXML
    private void onRestoreValues() {
        if (this.loadedSysCFGFile == null) {
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                """
                This action will reload the file from disk.
                
                All your changes will be lost, are you sure ?"""
                , ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Reload SysCFG ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            this.loadSysCFGFile(this.loadedSysCFGFile);
        }
    }

    @FXML
    private void onSave() {
        if (loadedSysCFG == null) {
            return;
        }
        saveSysCFGFile(loadedSysCFGFile);
    }

    @FXML
    private void onSaveAs() {
        if (loadedSysCFG == null) {
            return;
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Please select where to save the SysCFG you are editing");
        fileChooser.setInitialFileName("syscfg");
        File file = fileChooser.showSaveDialog(stage);
        if (file == null) {
            return;
        }
        saveSysCFGFile(file);
    }

    private void saveSysCFGFile(File file) {
        if (file == null) {
            return;
        }
        ByteBuffer toSave = SysCFG.asByteBuffer(loadedSysCFG);
        try {
            Files.write(file.toPath(), toSave.array());
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    String.format("""
                SysCFG saved successfully and reloaded from this path: %s""", file.toPath())
                    , ButtonType.OK);
            alert.setTitle("SysCFG saved successfully");
            alert.showAndWait();
            loadSysCFGFile(file);
        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    String.format("""
                Error while saving SysCFG (%s): %s""", file.toPath(), e.getMessage())
                    , ButtonType.OK);
            alert.setTitle("Error while saving SysCFG");
            alert.showAndWait();
        }
    }

    @FXML
    private void onAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION,
                String.format("""
                iPod SysCFG Editor, made with love by OlsroFR for the iPod Community
                
                Current version: %s""", Main.VERSION)
                , ButtonType.OK);
        alert.setTitle("About");
        alert.showAndWait();
    }

    @FXML
    private void onTurnInto202Pod() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                """
                Don't do that if your iPod is a 2.0.5 iPod Classic hardware revision ! Downgrading the firmware is not recommended.
                
                This will change these fields into the currently loaded SysCFG:
                - "Serial Number" last digits will be adjusted to a 7th gen Classic of same color
                - "Firmware ID" will be changed to: 21414D71
                - "Hardware Version" will be changed to: 130200
                - "Software Version" will be changed to: 2.0.2
                - "Model Number" will be changed to: MC297
                - "Sales region" will be changed to: 00020001 00210020"""
                , ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Modify currently loaded SysCFG ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            String newSn = iPodModelsBySNEnding.get7thGenSerialEquivalent(SysCFGEntryType.SYSCFG_TAG_SRNM.getPrintableValue(loadedSysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_SRNM)));
            if (newSn != null) {
                sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_SRNM).setText(newSn);
            }
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_FWID).setText("21414D71");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_HWVR).setText("130200");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_SWVR).setText("2.0.2");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_MODN).setText("MC297");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_REGN).setText("00020001 00210020");
        }
    }

    @FXML
    private void onTurnIntoFinalEUPod() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                """
                If your iPod is running a version older than 2.0.4, it's recommended to upgrade it only to 2.0.4 as the 2.0.5 version provides no meaningful benefit. iPod Classic < 2.0.5 firmwares don't have the EU volume limit (they only lack the option to enable it).
                
                This will change these fields into the currently loaded SysCFG:
                - "Serial Number" last digits will be adjusted to a 7th gen Classic of same color
                - "Firmware ID" will be changed to: 2501B683
                - "Hardware Version" will be changed to: 130300
                - "Software Version" will be changed to: 2.0.5
                - "Model Number" will be changed to: MC293
                - "Sales region" will be changed to: 00020001 00A10020"""
                , ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Modify currently loaded SysCFG ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            String newSn = iPodModelsBySNEnding.get7thGenSerialEquivalent(SysCFGEntryType.SYSCFG_TAG_SRNM.getPrintableValue(loadedSysCFG.entries().get(SysCFGEntryType.SYSCFG_TAG_SRNM)));
            if (newSn != null) {
                sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_SRNM).setText(newSn);
            }
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_FWID).setText("2501B683");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_HWVR).setText("130300");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_SWVR).setText("2.0.5");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_MODN).setText("MC293");
            sysCfgEntryTypeToTf.get(SysCFGEntryType.SYSCFG_TAG_REGN).setText("00020001 00A10020");
        }
    }

    @FXML
    private void onQuit() {
        System.exit(0);
    }
}

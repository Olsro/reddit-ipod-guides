package utils;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.function.BiFunction;

import objects.SysCFG;
import objects.SysCFGEntryType;

public class SysCFGEntryTypeUtils {
    private SysCFGEntryTypeUtils() {
    }

    public static final BiFunction<SysCFGEntryType, byte[], String> STRING_FORMAT_FUNCTION = (s, bb) -> {
        StringBuilder sb = new StringBuilder();
        for (byte b : bb) {
            char current = (char) b;
            if (current == 0) {
                break;
            }
            sb.append(current);
        }
        return sb.toString();
    };

    public static final TriFunction<SysCFGEntryType, String, byte[], byte[]> STRING_WRITE_FUNCTION = (s, v, pv) -> {
        ByteBuffer byteBuffer = ByteBuffer.allocate(SysCFG.SYSCFG_ENTRY_SIZE);
        byteBuffer.put(v.getBytes(StandardCharsets.US_ASCII));
        return byteBuffer.array();
    };
}

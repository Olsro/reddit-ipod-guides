package utils;

import java.nio.charset.StandardCharsets;

public class StringUtils {
    private StringUtils() {
    }

    public static boolean isValidInputString(String s) {
        return isPureAscii(s);
    }

    public static boolean isUpperHexaString(String s) {
        String pattern= "^[A-F0-9]*$";
        return s.matches(pattern);
    }

    public static boolean isPureAscii(String v) {
        return StandardCharsets.US_ASCII.newEncoder().canEncode(v);
    }
}

package objects;

public enum iPodModelsBySNEnding {
    CLASSIC_6_BLACK_80GO("YMV", "Classic 6th Gen (Black, 80GB)", objects.iPodColor.BLACK),
    CLASSIC_6_WHITE_80GO("Y5N", "Classic 6th Gen (White, 80GB)", objects.iPodColor.WHITE),
    CLASSIC_6_BLACK_160GO("YMX", "Classic 6th Gen (Black, 160GB)", objects.iPodColor.BLACK),
    CLASSIC_6_WHITE_160GO("YMU", "Classic 6th Gen (White, 160GB)", objects.iPodColor.WHITE),
    CLASSIC_6_5_BLACK_120GO("2C7", "Classic 6.5th Gen (Black, 120GB)", objects.iPodColor.BLACK),
    CLASSIC_6_5_WHITE_120GO("2C5", "Classic 6.5th Gen (White, 120GB)", objects.iPodColor.WHITE),
    CLASSIC_7_BLACK_160GO("9ZU", "Classic 7th Gen (Black, 160GB)", objects.iPodColor.BLACK),
    CLASSIC_7_WHITE_160GO("9ZS", "Classic 7th Gen (White, 160GB)", objects.iPodColor.WHITE),
    ;

    private final String snEnding;
    private final String description;
    private final iPodColor iPodColor;

    iPodModelsBySNEnding(String snEnding, String description, iPodColor iPodColor) {
        this.snEnding = snEnding;
        this.description = description;
        this.iPodColor = iPodColor;
    }

    public static String get7thGenSerialEquivalent(String sn) {
        if (sn.length() < 3) {
            return null;
        }
        final String snEnd = sn.substring(sn.length() - 3).toUpperCase();
        iPodModelsBySNEnding finalModel = CLASSIC_7_BLACK_160GO;
        for (iPodModelsBySNEnding iPodModelsBySNEnding : iPodModelsBySNEnding.values()) {
            if (iPodModelsBySNEnding.snEnding.equals(snEnd)) {
                if (iPodModelsBySNEnding.iPodColor == objects.iPodColor.WHITE) {
                    finalModel = CLASSIC_7_WHITE_160GO;
                }
                break;
            }
        }
        return sn.substring(0, sn.length() - 3) + finalModel.snEnding;
    }

    public static String getDescriptionBySNEnding(String sn) {
        if (sn.length() < 3) {
            return "Unknown";
        }
        final String snEnd = sn.substring(sn.length() - 3).toUpperCase();
        for (iPodModelsBySNEnding iPodModelsBySNEnding : iPodModelsBySNEnding.values()) {
            if (iPodModelsBySNEnding.snEnding.equals(snEnd)) {
                return iPodModelsBySNEnding.description;
            }
        }
        return "Unknown";
    }
}

package objects;

public record SysCFGHeader(
        int magic,
        int size,
        int unknown1,
        int version,
        int unknown2,
        int num_entries
) { }

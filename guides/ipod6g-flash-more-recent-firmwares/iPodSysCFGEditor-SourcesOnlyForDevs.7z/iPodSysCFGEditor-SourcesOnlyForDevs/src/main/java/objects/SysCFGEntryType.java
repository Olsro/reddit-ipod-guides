package objects;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.function.BiFunction;

import utils.SysCFGEntryTypeUtils;
import utils.TriFunction;

public enum SysCFGEntryType {
    SYSCFG_TAG_SRNM("SrNm", SysCFGEntryTypeUtils.STRING_FORMAT_FUNCTION,
            SysCFGEntryTypeUtils.STRING_WRITE_FUNCTION),
    SYSCFG_TAG_FWID("FwId", (s, bb) ->
            String.format("%08X", ByteBuffer.wrap(bb).order(ByteOrder.LITTLE_ENDIAN).getInt(4)),
            (s, v, pv) -> {
                ByteBuffer byteBuffer = ByteBuffer.wrap(pv);
                byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
                byteBuffer.putInt(4, Integer.parseUnsignedInt(v, 16));
                return byteBuffer.array();
            }),
    SYSCFG_TAG_HWID("HwId", (s, bb) ->
            String.format("%08X", ByteBuffer.wrap(bb).order(ByteOrder.LITTLE_ENDIAN).getInt()),
            (s, v, pv) -> {
                ByteBuffer byteBuffer = ByteBuffer.wrap(pv);
                byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
                byteBuffer.putInt(Integer.parseUnsignedInt(v, 16));
                return byteBuffer.array();
            }),
    SYSCFG_TAG_HWVR("HwVr", (s, bb) ->
            String.format("%06X", ByteBuffer.wrap(bb).order(ByteOrder.LITTLE_ENDIAN).getInt(4)),
            (s, v, pv) -> {
                ByteBuffer byteBuffer = ByteBuffer.wrap(pv);
                byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
                byteBuffer.putInt(4, Integer.parseUnsignedInt(v, 16));
                return byteBuffer.array();
            }),
    SYSCFG_TAG_CODC("Codc", SysCFGEntryTypeUtils.STRING_FORMAT_FUNCTION,
            SysCFGEntryTypeUtils.STRING_WRITE_FUNCTION),
    SYSCFG_TAG_SWVR("SwVr", SysCFGEntryTypeUtils.STRING_FORMAT_FUNCTION,
            SysCFGEntryTypeUtils.STRING_WRITE_FUNCTION),
    SYSCFG_TAG_MLBN("MLBN", SysCFGEntryTypeUtils.STRING_FORMAT_FUNCTION,
            SysCFGEntryTypeUtils.STRING_WRITE_FUNCTION),
    SYSCFG_TAG_MODN("Mod#", SysCFGEntryTypeUtils.STRING_FORMAT_FUNCTION,
            SysCFGEntryTypeUtils.STRING_WRITE_FUNCTION),
    SYSCFG_TAG_REGN("Regn", (s, bb) ->
        {
            ByteBuffer byteBuffer = ByteBuffer.wrap(bb);
            return String.format("%08X %08X",
                    byteBuffer.order(ByteOrder.LITTLE_ENDIAN).getInt(),
                    byteBuffer.order(ByteOrder.LITTLE_ENDIAN).getInt());
        },
        (s, v, pv) -> {
            ByteBuffer byteBuffer = ByteBuffer.wrap(pv);;
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
            String part1 = v.substring(0, 8);
            String part2 = v.substring(8);
            byteBuffer.putInt(Integer.parseUnsignedInt(part1, 16));
            byteBuffer.putInt(Integer.parseUnsignedInt(part2, 16));
            return byteBuffer.array();
        }
    )
    ;

    private final String tag;
    private final BiFunction<SysCFGEntryType, byte[], String> formatFunction;
    private final TriFunction<SysCFGEntryType, String, byte[], byte[]> writeFunction;

    SysCFGEntryType(String tag, BiFunction<SysCFGEntryType, byte[], String> formatFunction, TriFunction<SysCFGEntryType, String, byte[], byte[]> writeFunction) {
        this.tag = tag;
        this.formatFunction = formatFunction;
        this.writeFunction = writeFunction;
    }

    public boolean hasWriteFunction() {
        return this.writeFunction != null;
    }

    public boolean isStringFormatFunction() {
        return this.formatFunction == SysCFGEntryTypeUtils.STRING_FORMAT_FUNCTION;
    }

    public byte[] getDataToWrite(String v, byte[] previousValue) {
        return this.writeFunction.apply(this, v, previousValue.clone());
    }

    public void printWithValue(byte[] value) {
        System.out.printf("%s: %s%n", this.tag, this.getPrintableValue(value));
    }

    public String getPrintableValue(byte[] value) {
        return this.formatFunction.apply(this, value);
    }

    public int getTagAsBigEndianInt() {
        byte[] tagBytes = this.tag.getBytes(StandardCharsets.US_ASCII);
        return ByteBuffer.wrap(tagBytes).order(ByteOrder.BIG_ENDIAN).getInt();
    }

    public static SysCFGEntryType getEntryTypeByBigEndianInt(int value) {
        for (SysCFGEntryType sysCFGEntryType : SysCFGEntryType.values()) {
            if (sysCFGEntryType.getTagAsBigEndianInt() == value) {
                return sysCFGEntryType;
            }
        }
        return null;
    }
}

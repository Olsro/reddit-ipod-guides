package objects;

public enum iPodModelsBySNEndingModelNumber {
    CLASSIC_6_BLACK_80GO("YMV", "MB147", "Classic 6th Gen (Black, 80GB)", objects.iPodColor.BLACK),
    CLASSIC_6_WHITE_80GO("Y5N","MB029",  "Classic 6th Gen (White, 80GB)", objects.iPodColor.WHITE),
    CLASSIC_6_BLACK_160GO("YMX","MB150",  "Classic 6th Gen (Black, 160GB)", objects.iPodColor.BLACK),
    CLASSIC_6_WHITE_160GO("YMU","MB145",  "Classic 6th Gen (White, 160GB)", objects.iPodColor.WHITE),
    CLASSIC_6_5_BLACK_120GO("2C7","MB565",  "Classic 6.5th Gen (Black, 120GB)", objects.iPodColor.BLACK),
    CLASSIC_6_5_WHITE_120GO("2C5","MB562",  "Classic 6.5th Gen (White, 120GB)", objects.iPodColor.WHITE),
    CLASSIC_7_BLACK_160GO("9ZU","MC297",  "Classic 7th Gen (Black, 160GB)", objects.iPodColor.BLACK),
    CLASSIC_7_WHITE_160GO("9ZS","MC293",  "Classic 7th Gen (White, 160GB)", objects.iPodColor.WHITE),
    ;

    private final String snEnding;
    private final String modelNumber;
    private final String description;
    private final iPodColor iPodColor;

    iPodModelsBySNEndingModelNumber(String snEnding, String modelNumber, String description, iPodColor iPodColor) {
        this.snEnding = snEnding;
        this.modelNumber = modelNumber;
        this.description = description;
        this.iPodColor = iPodColor;
    }

    public static String get7thGenSerialEquivalent(String sn) {
        if (sn.length() < 3) {
            return null;
        }
        final String snEnd = sn.substring(sn.length() - 3).toUpperCase();
        iPodModelsBySNEndingModelNumber finalModel = CLASSIC_7_BLACK_160GO;
        for (iPodModelsBySNEndingModelNumber iPodModelsBySNEnding : iPodModelsBySNEndingModelNumber.values()) {
            if (iPodModelsBySNEnding.snEnding.equals(snEnd)) {
                if (iPodModelsBySNEnding.iPodColor == objects.iPodColor.WHITE) {
                    finalModel = CLASSIC_7_WHITE_160GO;
                }
                break;
            }
        }
        return sn.substring(0, sn.length() - 3) + finalModel.snEnding;
    }

    public static String get7thGenModelNumberEquivalent(String modelNumber) {
        if (modelNumber.length() < 5) {
            return null;
        }
        final String modelNumberShort = modelNumber.substring(0, 5).toUpperCase();
        iPodModelsBySNEndingModelNumber finalModel = CLASSIC_7_BLACK_160GO;
        for (iPodModelsBySNEndingModelNumber iPodModelsBySNEnding : iPodModelsBySNEndingModelNumber.values()) {
            if (iPodModelsBySNEnding.modelNumber.equals(modelNumberShort)) {
                if (iPodModelsBySNEnding.iPodColor == objects.iPodColor.WHITE) {
                    finalModel = CLASSIC_7_WHITE_160GO;
                }
                break;
            }
        }
        return finalModel.modelNumber + modelNumber.substring(5);
    }

    public static String getDescriptionBySNEnding(String sn) {
        if (sn.length() < 3) {
            return "Unknown";
        }
        final String snEnd = sn.substring(sn.length() - 3).toUpperCase();
        for (iPodModelsBySNEndingModelNumber iPodModelsBySNEnding : iPodModelsBySNEndingModelNumber.values()) {
            if (iPodModelsBySNEnding.snEnding.equals(snEnd)) {
                return iPodModelsBySNEnding.description;
            }
        }
        return "Unknown";
    }
}

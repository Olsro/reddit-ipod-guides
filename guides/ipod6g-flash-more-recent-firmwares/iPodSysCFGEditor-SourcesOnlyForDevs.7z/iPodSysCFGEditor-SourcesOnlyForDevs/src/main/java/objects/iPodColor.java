package objects;

public enum iPodColor {
    BLACK,
    WHITE
}

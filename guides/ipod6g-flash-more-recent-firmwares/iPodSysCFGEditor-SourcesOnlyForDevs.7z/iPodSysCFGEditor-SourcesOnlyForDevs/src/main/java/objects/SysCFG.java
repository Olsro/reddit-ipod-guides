package objects;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.EnumMap;

public record SysCFG(
        SysCFGHeader header,
        EnumMap<SysCFGEntryType, byte[]> entries
) {
    public static final int SYSCFG_VALID_MAGIC = 0x53436667;
    public static final int SYSCFG_MAX_ENTRIES = 9;
    public static final int SYSCFG_FILE_BYTES_SIZE = 204;
    public static final int SYSCFG_ENTRY_SIZE = 16;

    public static SysCFG parse(ByteBuffer buffer) {
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        SysCFGHeader header = new SysCFGHeader(buffer.getInt(),
                buffer.getInt(),
                buffer.getInt(),
                buffer.getInt(),
                buffer.getInt(),
                buffer.getInt());
        if (header.magic() != SYSCFG_VALID_MAGIC) {
            onCorruptedSysCFG("Invalid magic");
            return null;
        }
        EnumMap<SysCFGEntryType, byte[]> entries = new EnumMap<>(SysCFGEntryType.class);
        int syscfg_num_entries = Math.min(header.num_entries(), SYSCFG_MAX_ENTRIES);
        for (int i = 0; i < syscfg_num_entries; i++) {
            int tag = buffer.getInt();
            SysCFGEntryType sysCFGEntryType = SysCFGEntryType.getEntryTypeByBigEndianInt(tag);
            if (sysCFGEntryType == null) {
                onCorruptedSysCFG(String.format("Invalid entry tag: 0x%08X", tag));
                return null;
            }
            byte[] content = new byte[SYSCFG_ENTRY_SIZE];
            buffer.get(content);
            entries.put(sysCFGEntryType, content);
        }
        if (entries.size() != syscfg_num_entries) {
            onCorruptedSysCFG(String.format("Invalid parsed entries count (has %d, expected %d)", entries.size(), syscfg_num_entries));
            return null;
        }
        return new SysCFG(header, entries);
    }

    public static ByteBuffer asByteBuffer(SysCFG sysCFG) {
        ByteBuffer byteBuffer = ByteBuffer.allocate(SYSCFG_FILE_BYTES_SIZE);
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        byteBuffer.putInt(sysCFG.header.magic());
        byteBuffer.putInt(sysCFG.header.size());
        byteBuffer.putInt(sysCFG.header.unknown1());
        byteBuffer.putInt(sysCFG.header.version());
        byteBuffer.putInt(sysCFG.header.unknown2());
        byteBuffer.putInt(sysCFG.header.num_entries());
        for (SysCFGEntryType sysCFGEntryType : SysCFGEntryType.values()) {
            byteBuffer.putInt(sysCFGEntryType.getTagAsBigEndianInt());
            byteBuffer.put(sysCFG.entries.get(sysCFGEntryType));
        }
        return byteBuffer;
    }

    private static void onCorruptedSysCFG(String error) {
        System.err.println("[Corrupted SysCFG] " + error);
    }
}
